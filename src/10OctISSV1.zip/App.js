import React from 'react';
import { BrowserRouter, Route, Routes} from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import NewCompanydetailPage from './pages/NewCompanydetailPage';
import DashboardPage from './pages/DashboardPage';
import AGCompanyDetailPage from './pages/AGCompanyDetailPage';
import Accordion from './pages/Accordion';

import Modal from 'react-modal';
import CompanyRole from './pages/CompanyRole';

Modal.setAppElement('#root'); 


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LoginPage/>} />
        <Route path="/DashboardPage" element={<DashboardPage/>} />
        <Route path="/NewCompanydetailPage" element={<NewCompanydetailPage/>} />
        <Route path="/AGCompanyDetailPage" element={<AGCompanyDetailPage/>} />
        <Route path="/CompanyRole" element={<CompanyRole/>} />
        <Route path="/Accordion" element={<Accordion/>} />
       
      </Routes>
      </BrowserRouter> 
  );
}

export default App;
