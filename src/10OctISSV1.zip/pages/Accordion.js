import React, { useState } from 'react';
import '../components/Accordion.css';

import NewCompanydetailPage from './NewCompanydetailPage';
import DashboardPage from './DashboardPage';
import AGCompanyDetailPage from './AGCompanyDetailPage';

function Accordion() {
  const [accordion1Open, setAccordion1Open] = useState(false);
  const [accordion2Open, setAccordion2Open] = useState(false);
  const [accordion3Open, setAccordion3Open] = useState(false);

  return (
   
    <div>
      <button
       className={`accordion-button ${accordion1Open ? 'active' : ''}`}
       onClick={() => setAccordion1Open(!accordion1Open)}>
        Toggle Accordion 1
      </button>

      {accordion1Open && <AGCompanyDetailPage />}

      <button 
      className={`accordion-button ${accordion2Open ? 'active' : ''}`}
      onClick={() => setAccordion2Open(!accordion2Open)}>
        Toggle Accordion 2
      </button>
      {accordion2Open && <DashboardPage />}

      <button 
       className={`accordion-button ${accordion3Open ? 'active' : ''}`}
       onClick={() => setAccordion3Open(!accordion3Open)}>
        Toggle Accordion 3
      </button>
      {accordion3Open && <NewCompanydetailPage />}
    </div>
  );
}

export default Accordion;






{/* <div className="main">
    <h1>React Accordion</h1>
    <div className="accordion">
      <Accordion
        title="Item 1 - AG Company Detail Page"
        content={<AGCompanyDetailPage />}
      />
      <Accordion
        title="Item 2 - Dashboard Page"
        content={<DashboardPage />}
      />
      <Accordion
        title="Item 3 - New Company Detail Page"
        content={<NewCompanydetailPage />}
      />
    </div>
  </div> */}