import React from 'react';
function CompanyRole(){
    const Handlechange=()=>{

    }
    return(
<div>
    <label>ProcessCode</label>
<input
          type="text"
          placeholder="Search..."
         
          onChange={Handlechange()}
        />
        <label>ProcessCode</label>
<input
          type="text"
          placeholder="Search..."
          
          onChange={Handlechange()}
        />
        <label>ProcessCode</label>
<input
          type="text"
          placeholder="Search..."
          
          onChange={Handlechange()}
        />
        <label>ProcessCode</label>
<input
          type="text"
          placeholder="Search..."
          
          onChange={Handlechange()}
        />
        <label>ProcessCode</label>
<input
          type="text"
          placeholder="Search..."
          
          onChange={Handlechange()}
        />
</div>
    );
}export default CompanyRole;